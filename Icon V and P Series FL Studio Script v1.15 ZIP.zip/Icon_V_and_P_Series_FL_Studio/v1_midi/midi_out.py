from v1_core import refresher

def handle_refresh(flags):

    f = int(flags)  # freeze flags

    print(f"\n[FLAGS] Raw: {f} (0x{f:04X})")

    # HW_Dirty_Mixer_Sel (1) – mixer selection changed
    if f & 1:
        print("[REFRESH] Mixer Selection (1)")
        refresher.on_selected_track_change()

    # HW_Dirty_Mixer_Display (2) – mixer display changed
    if f & 2:
        print("[REFRESH] Mixer Display (2)")
        refresher.on_track_display_refresh()

    # HW_Dirty_Mixer_Controls (4) – mixer controls changed
    if f & 4:
        print("[REFRESH] Mixer Controls (4)")
        refresher.on_track_param_refresh()

    # HW_Dirty_RemoteLinks (16) – remote links (linked controls) has been added/removed
    if f & 16:
        print("[REFRESH] Remote Links (16)")
        refresher.on_remote_links_changed()

    # HW_Dirty_FocusedWindow (32) – channel selection changed
    #if f & 32:
        #print("[REFRESH] Focused Window (32)")
        #refresher.on_channel_selection_changed()

    # HW_Dirty_Performance (64) – performance layout changed
    if f & 64:
        print("[REFRESH] Performance Layout (64)")
        refresher.on_performance_layout_changed()

    # HW_Dirty_LEDs (256) – various changes in FL which require update of controller leds
    if f & 256:
        print("[REFRESH] LEDs (256)")
        refresher.on_transport_refresh()

    # HW_Dirty_RemoteLinkValues (512) – remote link (linked controls) value is changed
    if f & 512:
        print("[REFRESH] Remote Link Values (512)")
        refresher.on_remote_link_value_changed()

    # HW_Dirty_Patterns (1024) – pattern changes
    #if f & 1024:
        #print("[REFRESH] Patterns (1024)")
        #refresher.on_pattern_changed()

    # HW_Dirty_Tracks (2048) – track changes
    if f & 2048:
        print("[REFRESH] Mixer Tracks Changed (2048)")
        refresher.on_track_data_changed()

    # HW_Dirty_ControlValues (4096) – plugin control value changes
    if f & 4096:
        print("[REFRESH] Plugin Control Values (4096)")
        refresher.on_plugin_refresh()

    # HW_Dirty_Colors (8192) – plugin colors changes
    if f & 8192:
        print("[REFRESH] Plugin Colors (8192)")
        refresher.on_plugin_color_refresh()

    # HW_Dirty_Names (16384) – plugin names changes
    if f & 16384:
        print("[REFRESH] Plugin Names (16384)")
        refresher.on_plugin_name_refresh()

    # HW_Dirty_ChannelRackGroup (32768) – Channel rack group changes
    if f & 32768:
        print("[REFRESH] Channel Rack Group (32768)")
        refresher.on_channel_rack_group_changed()

    # HW_ChannelEvent (65536) – channel changes
    if f & 65536:
        print("[REFRESH] Channel Event (65536)")
        refresher.on_channel_change()
