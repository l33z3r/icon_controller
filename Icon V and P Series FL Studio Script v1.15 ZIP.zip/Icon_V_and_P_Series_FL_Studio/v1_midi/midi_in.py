# === SYSTEM IMPORTS ===
#import device, midi
import midi, transport, device, mixer

# === SCRIPT IMPORTS ===
from v1_core.payload import build_payload
from v1_core.shared_track_buffer import shared as track_buffer

# === MANAGERS ===
from v1_managers import (
    bank_manager,
    page_manager,
    vpot_manager,
    fader_manager,
    fader_m_manager,
    select_manager,
    msr_manager,
    jog_manager,
    transport_manager,
    button_manager,
)

from v1_core import mode_manager, jog_mode_manager

# === MIDI INPUT HANDLER ===
def receive_midi(event):
    status = event.status
    data1  = event.data1
    data2  = event.data2
    status_type = status & 0xF0
    midi_chan   = status & 0x0F
    raw_event = event

    # === JOGWHEEL Standard Turn ===
    if status == 0xB0 and data1 == 0x3C:
        event = {'status': status, 'data1': data1, 'data2': data2}
        payload = build_payload(event=event)
        jog_manager.adjust(payload)
        raw_event.handled = True
        return

    # === JOGWHEEL Horizontal & Vertical Buttons ===
    elif status == 0x90 and data1 in (0x60, 0x61, 0x62, 0x63):
        event = {'status': status, 'data1': data1, 'data2': data2}
        payload = build_payload(event=event)

        if data1 in (0x62, 0x63):  # Horizontal jog
            jog_manager.adjust_h(payload)
        else:  # 0x60, 0x61 → Vertical jog
            jog_manager.adjust_v(payload)
        raw_event.handled = True
        return

    # === PAGE BUTTONS ===
    if status == 0x90 and data1 in (0x2C, 0x2D) and data2 > 0:
        event = {'status': status, 'data1': data1, 'data2': data2}
        payload = build_payload(event=event)
        page_manager.press(payload)
        raw_event.handled = True
        return

    # === BANK BUTTONS ===
    if status == 0x90 and data1 in (0x2E, 0x2F, 0x30, 0x31) and data2 > 0:
        event = {'status': status,'data1': data1,'data2': data2,}
        payload = build_payload(event=event)
        bank_manager.press(payload)  # local action

        # Dispatch to Extenders
        name = device.getName()
        if "1-X" in name.upper():
            pass
        else:
            for i in range(device.dispatchReceiverCount()):
                device.dispatch(i, 0x90 + (data1 << 8) + (data2 << 16))
        # === DEBUG ===
        print("[BANK] is extender:", "1-X" in device.getName().upper())
        print("[BANK] dispatch receivers:", device.dispatchReceiverCount())
        raw_event.handled = True
        return

    # === MODE BUTTONS ===
    MODES = {
        0x28: "standard_mode",
        0x29: "stereo_mode",
        0x2A: "send_mode",
        0x2B: "plugin_mode",
        0x36: "receive_mode",
        0x37: "eq_mode",
        0x38: "color_meter_mode",
        0x39: "eq2_mode",
        0x3A: "track_pan_mode",
        0x3B: "track_vol_mode",
    }

    if status == 0x90 and data2 > 0 and data1 in MODES:
        event = {'status': status, 'data1': data1, 'data2': data2, 'name': MODES[data1]}
        payload = build_payload(event=event)
        mode_manager.press(payload)
        mode_name = MODES[data1]

        # MODES NOT DISPATCHED TO EXTENDERS
        DISPATCH_BLOCKED_MODES = {
            "plugin_mode",
            "eq_mode",
            "eq2_mode",
        }

        # DISPATCH TO EXTENDERS
        name = device.getName()
        if mode_name in DISPATCH_BLOCKED_MODES:
            raw_event.handled = True
            return
        if "1-X" in name.upper():
            pass
        else:
            for i in range(device.dispatchReceiverCount()):
                device.dispatch(i, 0x90 + (data1 << 8) + (data2 << 16))

        # === DEBUG ===
        print("[MODE] is extender:", "1-X" in device.getName().upper())
        print("[MODE] dispatch receivers:", device.dispatchReceiverCount())
        raw_event.handled = True
        return

    # === JOG MODE BUTTONS ===
    JOG_MODES = {
        0x64: "jog_zoom_mode",
        0x71: "jog_slow_mode",
        0x72: "jog_precise_mode",
        0x73: "jog_undo_mode",
        0x74: "jog_sort_mode",
        0x75: "jog_snap_mode",
        0x76: "jog_tempo_mode",
    }

    if status == 0x90 and data2 > 0 and data1 in JOG_MODES:
        event = {'status': status, 'data1': data1, 'data2': data2, 'name': JOG_MODES[data1]}
        payload = build_payload(event=event)
        jog_mode_manager.press(payload)
        raw_event.handled = True
        return

    # === SELECT / MUTE / SOLO / REC press ===
    if status == 0x90 and data1 in range(0x00, 0x20) and data2 > 0:
        event = {'status': status, 'data1': data1, 'data2': data2}
        payload = build_payload(event=event)
        if midi_chan == 0 and data1 in range(0x18, 0x20):
            select_manager.press(payload)
        else:
            msr_manager.press(payload)
        raw_event.handled = True
        return

    # === VPOT TURN (CC on ch 0–7, data1 0x10–0x17) ===
    if (status & 0xF0) == 0xB0 and 0x10 <= data1 <= 0x17:
        event = {'status': status, 'data1': data1, 'data2': data2}
        payload = build_payload(event=event)
        vpot_manager.adjust(payload)
        raw_event.handled = True
        return

    # === VPOT PRESS (Note on ch 0–7, data1 0x20–0x27) ===
    if (status & 0xF0) == 0x90 and data2 > 0 and 0x20 <= data1 <= 0x27:
        event = {'status': status,'data1': data1,'data2': data2}
        payload = build_payload(event=event)
        vpot_manager.press(payload)
        raw_event.handled = True
        return

    # === FADER PITCH BEND (0xE0–0xE7) ===
    if status_type == 0xE0 and midi_chan in range(8):
        event = {'status': status,'data1': data1,'data2': data2,'midiChan': midi_chan,}
        payload = build_payload(event=event)
        fader_manager.adjust(payload)
        raw_event.handled = True
        return

    # === MASTER FADER PITCH BEND: Channel 8 ===
    if status_type == 0xE0 and midi_chan == 8:
        event = {'status': status,'data1': data1,'data2': data2,'midiChan': midi_chan}
        payload = build_payload(event=event)
        fader_m_manager.adjust(payload)
        raw_event.handled = True
        return

    # Extra Code needed for Ableton Note Off support for REWIND/FORWARD
    if status_type == 0x80:
        status_type = 0x90
        data2 = 0

    # === TRANSPORT BUTTONS ===
    if status_type == 0x90:

        if data1 in (0x5D, 0x5E, 0x5F, 0x56) and data2 > 0:  # STOP, PLAY, RECORD, LOOP
            event = {'status': status, 'data1': data1, 'data2': data2}
            payload = build_payload(event=event)
            transport_manager.press(payload)
            raw_event.handled = True
            return

        elif data1 in (0x5B, 0x5C):  # REWIND, FORWARD (press OR release)
            event = {'status': status, 'data1': data1, 'data2': data2}
            payload = build_payload(event=event)
            transport_manager.hold(payload)
            raw_event.handled = True
            return

    # === Track Name + Color Buttons (Channel 2, Notes 0–23) ===
    if status == 0x91 and 0 <= data1 <= 23 and data2 > 0:
        event = {'status': status, 'data1': data1, 'data2': data2}
        payload = build_payload(event=event)
        button_manager.press(payload)
        return

    # === COLOR-ONLY BUTTONS (Channel 3, Notes 0–23) ===
    if status == 0x92 and 0 <= data1 <= 23 and data2 > 0:
        event = {'status': status, 'data1': data1, 'data2': data2}
        payload = build_payload(event=event)
        button_manager.press(payload)
        return

    # === Buttons ===
    BTN = {
        0x35: "clock_toggle",
        0x52: "marker_toggle",
        0x54: "marker_prev",
        0x55: "marker_next",
        0x4C: "undo",
        0x4F: "redo",
        0x7A: "close windows",
        0x7B: "playlist",
        0x7C: "piano roll",
        0x7D: "channel rack",
        0x7E: "mixer",
        0x7F: "browser",
        0x32: "flip",
        0x57: "metronome",
        0x58: "countdown",
        0x5A: "song_pattern",
    }
    if status == 0x90 and data2 > 0 and data1 in BTN:  # Note On (any channel)
        event = {'status': status, 'data1': data1, 'data2': data2, 'name': BTN[data1]}
        payload = build_payload(event=event)
        button_manager.press(payload)

        # === DISPATCH ONLY FOR FLIP ===
        btn_name = BTN[data1]
        if btn_name == "flip":
            dev_name = device.getName()
            if "1-X" not in dev_name.upper():
                for i in range(device.dispatchReceiverCount()):
                    device.dispatch(i, 0x90 + (data1 << 8) + (data2 << 16))

        raw_event.handled = True
        return

    # FL Studio Only
    # === Block all other note input to prevent FL default preview ===
    elif event.midiId in (midi.MIDI_NOTEON, midi.MIDI_NOTEOFF):
        event.handled = True  # Suppress FL Channel Rack from triggering notes

    # === Block everything unmapped ===
    if not event.handled and event.status in [0x80, 0x90]:
        event.handled = True

