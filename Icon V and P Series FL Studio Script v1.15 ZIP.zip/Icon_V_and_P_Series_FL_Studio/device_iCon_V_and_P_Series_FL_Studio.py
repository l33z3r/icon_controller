# name=iCon_V_and_P_Series_FL_Studio
# supportedDevices=Icon V and P Series
# version=1.15
import midi
from v1_core.initialiser import Initialiser

def OnInit():
    global initialiser
    initialiser = Initialiser()
    initialiser.OnInit()

def OnDeInit():
    from v1_core.deinitialiser import Deinitialiser
    Deinitialiser().OnDeinit()

def OnMidiMsg(event):
    import v1_midi.midi_in as midi_in
    midi_in.receive_midi(event)

def OnRefresh(flags):
    import v1_midi.midi_out as midi_out
    midi_out.handle_refresh(flags)

def OnIdle():
    from v1_core import onidle
    onidle.run()
