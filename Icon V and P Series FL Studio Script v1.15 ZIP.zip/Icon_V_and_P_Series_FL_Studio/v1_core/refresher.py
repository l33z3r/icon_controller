# === SCRIPT IMPORTS ===
from v1_core.shared_track_buffer import shared as shared_tracks
from v1_core.payload import build_payload
from v1_managers import scribble_1_manager, scribble_2_manager, scribble_3_manager, scribble_4_manager, colorband_manager, fader_manager, fader_m_manager, select_manager, msr_manager, vpot_manager, transport_manager, button_manager, meter_manager
from v1_core import switch_manager as SW

# === BANKING REFRESH ===
def on_bank_changed(payload): # FL
    tracks = payload.get("tracks")

    payload = build_payload()
    scribble_1_manager.refresh(payload)
    scribble_2_manager.refresh(payload)
    scribble_3_manager.refresh(payload)
    scribble_4_manager.refresh(payload)
    colorband_manager.refresh(payload)
    fader_manager.refresh(payload)
    select_manager.refresh(payload)
    msr_manager.refresh(payload)
    vpot_manager.refresh(payload)

# === PAGE REFRESH ===
def on_page_changed(payload):

    payload = build_payload()
    vpot_manager.refresh(payload)
    scribble_1_manager.refresh(payload)
    scribble_2_manager.refresh(payload)

# === SWITCH CHANGES (FLIP MODE etc.) ===
#def on_switch_change(payload):

# === DAW flag refresh ====
def on_selected_track_change():
    payload = build_payload()
    select_manager.refresh(payload)
    msr_manager.refresh(payload)

def on_track_display_refresh():
    payload = build_payload()
    scribble_1_manager.refresh(payload)
    scribble_2_manager.refresh(payload)
    scribble_3_manager.refresh(payload)
    scribble_4_manager.refresh(payload)
    colorband_manager.refresh(payload)

def on_track_param_refresh():
    payload = build_payload()
    fader_manager.refresh(payload)
    fader_m_manager.refresh(payload)
    vpot_manager.refresh(payload)

def on_transport_refresh():
    payload = build_payload()
    transport_manager.refresh(payload)
    button_manager.refresh(payload)

def on_plugin_refresh():
    payload = build_payload()
    scribble_2_manager.refresh(payload)
    vpot_manager.refresh(payload)
    fader_manager.refresh(payload)

# === REFRESH HANDLERS FOR MODE CHANGES (ONLY USED MANAGERS) ===
def on_mode_changed(payload):
    payload = build_payload()

    # refresh if mode-sensitive
    scribble_1_manager.refresh(payload)
    scribble_2_manager.refresh(payload)
    scribble_3_manager.refresh(payload)
    scribble_4_manager.refresh(payload)
    colorband_manager.refresh(payload)
    vpot_manager.refresh(payload)
    fader_manager.refresh(payload)
    msr_manager.refresh(payload)
    select_manager.refresh(payload)
    meter_manager.refresh(payload)

# === SWITCH CHANGES (FLIP MODE etc.) ===
def on_switch_change(payload):
    payload = build_payload()

    # refresh if mode-sensitive
    scribble_1_manager.refresh(payload)
    scribble_2_manager.refresh(payload)
    scribble_3_manager.refresh(payload)
    scribble_4_manager.refresh(payload)
    colorband_manager.refresh(payload)
    vpot_manager.refresh(payload)
    fader_manager.refresh(payload)
    msr_manager.refresh(payload)
    select_manager.refresh(payload)
    meter_manager.refresh(payload)

# === SEND MODE ===
def handle_send_change(payload):
    scribble_2_manager.refresh(payload)
    vpot_manager.refresh(payload)
    fader_manager.refresh(payload)

# === PLUGIN MODE ===
def handle_devices_change(payload):
    scribble_1_manager.refresh(payload)
    scribble_2_manager.refresh(payload)
    scribble_3_manager.refresh(payload)
    scribble_4_manager.refresh(payload)
    vpot_manager.refresh(payload)
    fader_manager.refresh(payload)

def handle_selected_device_change(payload):
    scribble_1_manager.refresh(payload)
    scribble_2_manager.refresh(payload)
    scribble_3_manager.refresh(payload)
    scribble_4_manager.refresh(payload)
    vpot_manager.refresh(payload)

def handle_any_param_change(payload):
    scribble_1_manager.refresh(payload)
    scribble_2_manager.refresh(payload)
    scribble_3_manager.refresh(payload)
    scribble_4_manager.refresh(payload)
    vpot_manager.refresh(payload)
