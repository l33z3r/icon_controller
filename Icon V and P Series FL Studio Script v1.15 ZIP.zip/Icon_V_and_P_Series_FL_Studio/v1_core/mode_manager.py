_LAST_MODE_LED = None

def press(payload):
    from v1_core.shared_mode_buffer import shared as shared_mode
    from v1_core import refresher

    d1 = payload.get("data1")
    d2 = payload.get("data2")

    mode_map = {
        0x28: "standard_mode",
        0x29: "stereo_mode",
        0x2A: "send_mode",
        0x2B: "plugin_mode",
        0x36: "receive_mode",
        0x37: "eq_mode",
        0x38: "color_meter_mode",
        0x39: "eq2_mode",
        0x3A: "track_pan_mode",
        0x3B: "track_vol_mode",
    }

    requested = mode_map[d1]
    current   = (shared_mode.get_mode() or "").strip().lower()
    new_mode = "standard_mode" if requested == current else requested

    if new_mode != current:
        shared_mode.set_mode(new_mode)
        refresh(payload)                   # LED update (DAW-driven render)
        refresher.on_mode_changed(payload) # notify other parts

# === REFRESH: LED state ===
def refresh(payload):
    global _LAST_MODE_LED
    from v1_core.shared_mode_buffer import shared as shared_mode

    DM = payload.get("daw_map")

    current = (shared_mode.get_mode() or "").strip().lower()
    if current == _LAST_MODE_LED:
        return

    msgs = [
        (0x90, 0x28, 127 if current == "standard_mode" else 0),
        (0x90, 0x29, 127 if current == "stereo_mode" else 0),
        (0x90, 0x2A, 127 if current == "send_mode" else 0),
        (0x90, 0x2B, 127 if current in ("plugin_mode", "plugin2_mode") else 0),  # PLUGIN (1 or 2 share this LED)
        (0x90, 0x36, 127 if current == "receive_mode" else 0),
        (0x90, 0x37, 127 if current == "eq_mode" else 0),
        (0x90, 0x38, 127 if current == "color_meter_mode" else 0),
        (0x90, 0x39, 127 if current == "eq2_mode" else 0),
        (0x90, 0x3A, 127 if current == "track_pan_mode" else 0),
        (0x90, 0x3B, 127 if current == "track_vol_mode" else 0),
    ]
    for m in msgs:
        DM.SEND_DAW(payload, m)

    _LAST_MODE_LED = current
