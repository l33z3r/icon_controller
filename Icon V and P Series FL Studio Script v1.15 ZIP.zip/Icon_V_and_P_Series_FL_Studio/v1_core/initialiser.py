# === SYSTEM IMPORTS ===
import midi, device, mixer, transport, ui

# === SHARED BUFFERS & UTILS ===
from v1_core.shared_track_buffer import shared as track_buffer
from v1_core.shared_mode_buffer import shared as mode_buffer
from v1_core.shared_jog_mode_buffer import shared as jog_mode_buffer
from v1_core import mode_manager, jog_mode_manager
from v1_core.payload import build_payload

# === MANAGERS / BUFFERS ===
from v1_managers import transport_manager, select_manager, msr_manager, fader_m_manager, fader_manager, vpot_manager, bank_manager, scribble_1_manager, scribble_2_manager, scribble_3_manager, scribble_4_manager, colorband_manager, clock_manager, button_manager

class Initialiser:
    def __init__(self):
        print("[Initialiser] Init")
        self.mode = mode_buffer
        self.jog_mode = jog_mode_buffer

    # === INITIALISATION: MODE / REFRESH DEFAULT STATE ===
    def OnInit(self):
        self.mode.set_mode("standard_mode")
        self.jog_mode.set_mode("jog_standard_mode")

        payload = build_payload()
        tracks = bank_manager.refresh(payload)
        payload["tracks"] = tracks
        mode_manager.refresh(build_payload())
        jog_mode_manager.refresh(build_payload())
        button_manager.refresh(build_payload())
        vpot_manager.refresh(build_payload())
        scribble_1_manager.refresh(build_payload())
        scribble_2_manager.refresh(build_payload())
        scribble_3_manager.refresh(build_payload())
        scribble_4_manager.refresh(build_payload())
        colorband_manager.refresh(build_payload())
        fader_manager.refresh(build_payload())
        fader_m_manager.refresh(build_payload())
        select_manager.refresh(build_payload())
        msr_manager.refresh(build_payload())
        transport_manager.refresh(build_payload())
        clock_manager.refresh(build_payload())

        print("[Initialiser] OnInit complete")
