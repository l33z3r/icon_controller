from v1_core.payload import build_payload as _build_payload
from v1_handlers import standard_meter_m, standard_meter, standard_clock, standard_transport, meter_colorband
from v1_core.temp_text_manager import TEMP_REFRESH
from v1_core.shared_mode_buffer import shared as mode_buffer

_TICKS = None

def run():
    global _TICKS

    if _TICKS is None:
        ticks = [
            getattr(standard_meter,     "tick", None),
            getattr(meter_colorband,    "tick", None),
            getattr(standard_meter_m,   "tick", None),
            getattr(standard_clock,     "tick", None),
            getattr(standard_transport, "tick", None),
            TEMP_REFRESH,
        ]
        _TICKS = [t for t in ticks if t]

    payload = _build_payload()

    for t in _TICKS:
        try:
            if t == getattr(meter_colorband, "tick", None):
                if mode_buffer.get_mode() != "color_meter_mode":
                    continue

            t(payload)

        except Exception as e:
            print(f"(onidle) tick error: {e}")