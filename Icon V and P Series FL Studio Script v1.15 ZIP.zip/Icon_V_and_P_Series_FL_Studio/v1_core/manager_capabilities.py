# === HANDLERS ===
from v1_handlers import (

    # --- BANK / NAVIGATION ---
    standard_bank,

    # --- VPOTS ---
    standard_vpot,
    stereo_vpot,
    send_vpot,
    receive_vpot,
    eq_vpot,
    eq2_vpot,
    plugin_vpot,
    plugin2_vpot,

    # --- FADERS ---
    standard_fader,
    standard_fader_m,
    eq_fader,
    eq2_fader,

    # --- SCRIBBLE STRIPS : ROW 1 ---
    standard_scribble_1,
    eq_scribble_1,
    eq2_scribble_1,
    plugin_scribble_1,
    plugin2_scribble_1,
    pan_scribble_1,
    vol_scribble_1,

    # --- SCRIBBLE STRIPS : ROW 2 ---
    standard_scribble_2,
    eq_scribble_2,
    eq2_scribble_2,
    plugin_scribble_2,
    plugin2_scribble_2,
    pan_scribble_2,
    vol_scribble_2,

    # --- SCRIBBLE STRIPS : ROW 3 ---
    standard_scribble_3,
    eq_scribble_3,
    eq2_scribble_3,
    plugin_scribble_3,
    plugin2_scribble_3,
    pan_scribble_3,
    vol_scribble_3,

    # --- SCRIBBLE STRIPS : ROW 4 ---
    standard_scribble_4,
    eq_scribble_4,
    eq2_scribble_4,
    plugin_scribble_4,
    plugin2_scribble_4,
    pan_scribble_4,
    vol_scribble_4,

    # --- COLOR BANDS ---
    standard_colorband,
    eq2_colorband,
    meter_colorband,

    # --- SELECT / MSR ---
    standard_select,
    receive_select,
    plugin_select,
    standard_msr,

    # --- TRANSPORT / BUTTONS ---
    standard_transport,
    standard_button,

    # --- PAGING ---
    standard_page,
    plugin_page,
    plugin2_page,
    eq2_page,

    # --- METERS ---
    standard_meter,
    standard_meter_m,
)

# === CHECK MANAGER CAPIBILITY, IF UNSUPPORTED DEFAULT TO STANDARD MODE ===

# Bank manager
bank_manager_capabilities = {
    "standard_mode": standard_bank,
}

# Vpot manager
vpot_manager_capabilities = {
    "standard_mode": standard_vpot,
    "plugin_mode": plugin_vpot,
    "plugin2_mode": plugin2_vpot,
    "send_mode": send_vpot,
    "stereo_mode": stereo_vpot,
    "receive_mode": receive_vpot,
    "eq_mode": eq_vpot,
    "eq2_mode": eq2_vpot,
}

# Fader manager
fader_manager_capabilities = {
    "standard_mode": standard_fader,
    "eq_mode": eq_fader,
    "eq2_mode": eq2_fader,
}

# Master Fader manager
fader_m_manager_capabilities = {
    "standard_mode": standard_fader_m,
}

# Select manager
select_manager_capabilities = {
    "standard_mode": standard_select,
    "receive_mode": receive_select,
    "plugin_mode": plugin_select,
}

# MSR manager
msr_manager_capabilities = {
    "standard_mode": standard_msr,
}

# Transport manager
transport_manager_capabilities = {
    "standard_mode": standard_transport,
}

# scribble 1 manager
scribble_1_manager_capabilities = {
    "standard_mode": standard_scribble_1,
    "plugin_mode": plugin_scribble_1,
    "plugin2_mode": plugin2_scribble_1,
    "eq_mode": eq_scribble_1,
    "eq2_mode": eq2_scribble_1,
    "track_pan_mode": pan_scribble_1,
    "track_vol_mode": vol_scribble_1,
}

# scribble 2 manager
scribble_2_manager_capabilities = {
    "standard_mode": standard_scribble_2,
    "plugin_mode": plugin_scribble_2,
    "plugin2_mode": plugin2_scribble_2,
    "eq_mode": eq_scribble_2,
    "eq2_mode": eq2_scribble_2,
    "track_pan_mode": pan_scribble_2,
    "track_vol_mode": vol_scribble_2,
}

# scribble 3 manager
scribble_3_manager_capabilities = {
    "standard_mode": standard_scribble_3,
    "plugin_mode": plugin_scribble_3,
    "plugin2_mode": plugin2_scribble_3,
    "eq_mode": eq_scribble_3,
    "eq2_mode": eq2_scribble_3,
    "track_pan_mode": pan_scribble_3,
    "track_vol_mode": vol_scribble_3,
}

# scribble 4 manager
scribble_4_manager_capabilities = {
    "standard_mode": standard_scribble_4,
    "plugin_mode": plugin_scribble_4,
    "plugin2_mode": plugin2_scribble_4,
    "eq_mode": eq_scribble_4,
    "eq2_mode": eq2_scribble_4,
    "track_pan_mode": pan_scribble_4,
    "track_vol_mode": vol_scribble_4,
}

# Colorband manager
colorband_manager_capabilities = {
    "standard_mode": standard_colorband,
    "eq2_mode": eq2_colorband,
}

# Meter manager
meter_manager_capabilities = {
    "standard_mode": standard_meter,
    "color_meter_mode": meter_colorband,
}

# Master Meter manager
meter_m_manager_capabilities = {
    "standard_mode": standard_meter_m,
}

# Buttons manager
button_manager_capabilities = {
    "standard_mode": standard_button,
}

# Page manager
page_manager_capabilities = {
    "standard_mode": standard_page,
    "plugin_mode": plugin_page,
    "plugin2_mode": plugin2_page,
    "eq2_mode": eq2_page,
}
