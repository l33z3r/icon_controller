# === IMPORTS ===
import mixer
from v1_core import switch_manager as SW

# === DEFINE HARDWARE TRACK ===
class HardwareTrack:
    def __init__(self, track_index, index):
        self.live_track = track_index          # FL Studio uses track index, not object
        self.TrackNum   = index                # hardware slot index (0–7)

# === SHARED TRACK BUFFER FOR FL STUDIO ===
class TrackBuffer:
    def __init__(self):
        self.first_track   = 1
        self.visible_slots = 8
        self.track_count   = 0
        self.min_track     = 1

    def get_current_tracks(self):
        # FL Studio only has mixer tracks (no returns, yet...)
        self.track_count = mixer.trackCount()

        tracks = []
        for i in range(self.visible_slots):
            index = self.first_track + i

            # FL stores track as integer index (NOT a Live object)
            track_index = index if index < self.track_count else None

            tracks.append(HardwareTrack(track_index, index))

        return tracks

    def bank(self, amount):
        self.first_track = max(self.min_track, self.first_track + amount)
        return self.get_current_tracks()
