# === BUILD PAYLOAD (FL STUDIO VERSION) ===
def build_payload(event=None, **overrides):
    import mixer, midi, device, transport, playlist

    from v1_core.shared_track_buffer import shared as shared_tracks
    from v1_core.shared_mode_buffer import shared as shared_mode
    from v1_core.shared_jog_mode_buffer import shared as shared_jog_mode

    from v1_core import daw_map
    from v1_core import addresses as addr
    from v1_core import led_cache
    from v1_core import refresher
    from v1_core import temp_text_manager

    payload = {
        # === MIDI EVENT FIELDS (FL native) ===
        "data1":     getattr(event, "data1", None),
        "data2":     getattr(event, "data2", None),
        "status":    getattr(event, "status", None),
        "delta":     getattr(event, "delta", None),
        "pmeFlags": getattr(event, 'pmeFlags', None),
        "button_id": getattr(event, "button_id", None),
        "value":     getattr(event, "value", None),
        "midiChan":  getattr(event, "midiChan", None),
        "event":     event,

        # === TRACK BUFFERS ===
        "tracks":       shared_tracks.get_current_tracks(),
        "track_buffer": shared_tracks,

        # === DAW MODULES (FL native) ===
        "mixer":     mixer,
        "midi":      midi,
        "transport": transport,
        "device":    device,
        "playlist":  playlist,

        # === SHARED STATES / BUFFERS ===
        "shared_mode":     shared_mode.get_mode(),
        "shared_jog_mode": shared_jog_mode.get_mode(),

        # === V-SERIES CORE ===
        "addr":       addr,
        "led_cache":  led_cache,
        "daw_map":    daw_map,
        "refresher":  refresher,
        "temp_text":  temp_text_manager,

        # === EXTRAS ===
        "meter_mode": 2,
    }

    # === DICT EVENT SUPPORT (Ableton-style parity) ===
    if isinstance(event, dict):
        if "status" in event:
            payload["status"] = event["status"]
        if "data1" in event:
            payload["data1"] = event["data1"]
        if "data2" in event:
            payload["data2"] = event["data2"]
        if "midiChan" in event:
            payload["midiChan"] = event["midiChan"]

    # === APPLY OVERRIDES ===
    payload.update(overrides)

    return payload
