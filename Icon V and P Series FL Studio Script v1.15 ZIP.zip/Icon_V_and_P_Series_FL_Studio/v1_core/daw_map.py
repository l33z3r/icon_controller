# === FL STUDIO DAW MAP ===
import midi, device, mixer, transport, ui, playlist, plugins, general

# === JOGWHEEL ===
JUMP_BY = lambda p, d: transport.globalTransport(midi.FPT_Jog, d, 111)
SCROLL  = lambda p, d, m: transport.globalTransport(d, m, 111)
ZOOM    = lambda p, d, m: transport.globalTransport(d, m, 111)
SORT    = lambda d: transport.globalTransport(midi.FPT_MoveJog, d, 111)
SNAP    = lambda d: transport.globalTransport(midi.FPT_SnapMode, d, 111)
UNDO    = lambda d: transport.globalTransport(midi.FPT_UndoJog, d, 111)
TEMPO   = lambda d: transport.globalTransport(midi.FPT_TempoJog, d, 111)
S_L     = lambda p: midi.FPT_Left
S_R     = lambda p: midi.FPT_Right
S_U     = lambda p: midi.FPT_Up
S_D     = lambda p: midi.FPT_Down
Z_H     = lambda p: midi.FPT_HZoomJog
Z_V     = lambda p: midi.FPT_VZoomJog
CURRENT_SONGPOS = lambda p: transport.getSongPos(2)
NEW_SONGPOS     = lambda p, v: transport.setSongPos(float(v), 2)

# === REPEATABLE DAW COMMANDS ===
SEND_DAW     = lambda p, sysex_tuple: p["device"].midiOutSysex(bytes(sysex_tuple))
TRACK_LIVE   = lambda p, i: p['tracks'][i] if 0 <= i < len(p['tracks']) else None
GET_DAWTRACK = lambda p: type("DT", (), {"TrackNum": mixer.trackNumber()})()
SET_LED      = lambda p, st, d1, d2: p["device"].midiOutSysex(bytes([st, d1, d2]))
HAS_AUDIO    = lambda p, i: ((t := p['tracks'][i].TrackNum) and 1 <= t <= mixer.trackCount() - 2 and (mixer.getTrackName(t) != f"Insert {t}" or mixer.getTrackColor(t)))
_2_BYTE_MSG  = lambda _1, _2: (_1, _2)
_3_BYTE_MSG  = lambda _1, _2, _3: (_1, _2, _3)
_4_BYTE_MSG  = lambda _1, _2, _3, _4: (_1, _2, _3, _4)
DAW_TRACK    = lambda t: t
TRACK_COUNT  = lambda: mixer.trackCount()

# === TEMP TEXT FORMAT ===
TRACK_DB  = lambda dt: ((lambda db: ("-inf dB" if db <= -90.0 else f"{db:.1f}dB"))(mixer.getTrackVolume(dt.TrackNum, 1)))
TRACK_PAN = lambda dt: ((lambda p, prefix, pct:(f"{prefix}{pct:.1f}%")[:7].ljust(7))(pan := mixer.getTrackPan(dt.TrackNum),"C " if abs(pan) < 0.005 else ("L " if pan < 0 else "R "),abs(pan) * 100.0))
TRACK_SEP = lambda dt: ((lambda p, prefix, pct: (f"{prefix}{pct:.1f}%")[:7].ljust(7))(sep := mixer.getTrackStereoSep(dt.TrackNum),"O " if abs(sep) < 0.005 else ("S " if sep < 0 else "M "),abs(sep) * 100.0))
TEMPO_TXT = lambda p: ("%d BPM" % mixer.getCurrentTempo(1))[:7].ljust(7)
WET_TXT   = lambda p, DT, SLOT: f"{int(mixer.getPluginMixLevel(int(getattr(DT, 'TrackNum', DT)), SLOT) * 100)}%"

# === TEXT SMART FORMAT ===
def SMART7(s, width=7):
    s = (s or '').strip()
    if not s:
        return ' ' * int(width)
    if len(s) <= width:
        return s[:int(width)]
    for ch in (' ', 'i', 'o', 'u', 'e', 'a', '-', '_'):
        while len(s) > width:
            pos = s.rfind(ch, 1)
            if pos <= 0:
                break
            s = s[:pos] + s[pos+1:]
        if len(s) <= width:
            break
    return s[:int(width)]

# === BANK REFRESH - TRACK POSITIONS ===
SLOT_GET = lambda p: (((device.getPortNumber() % 100) - 1) * 8 + 1 if 1 <= (device.getPortNumber() % 100) <= 8 else 1)

# === VPOTS & PAN ===
PAN_GET = lambda dt: mixer.getTrackPan(dt.TrackNum)
PAN_SET = lambda dt, v: mixer.setTrackPan(dt.TrackNum, v)
# STEREO MODE
STE_GET = lambda dt: mixer.getTrackStereoSep(dt.TrackNum)
STE_SET = lambda dt, v: mixer.setTrackStereoSep(dt.TrackNum, v)
# SEND MODE
SEND_ACTIVE = lambda p, dt: mixer.getRouteSendActive(mixer.trackNumber(), dt.TrackNum)
SEND_GET    = lambda p, dt: mixer.getRouteToLevel(mixer.trackNumber(), dt.TrackNum)
SEND_SET    = lambda p, dt, v: mixer.setRouteToLevel(mixer.trackNumber(), dt.TrackNum, v)
SEND_TOGGLE = lambda p, dt: ((lambda r: (mixer.setRouteTo(mixer.trackNumber(), 0, 0),mixer.afterRoutingChanged(),r)[-1])(mixer.setRouteTo(mixer.trackNumber(), dt.TrackNum, -1)))
# RECEIEVE MODE
IS_SELECTED         = lambda t: mixer.isTrackSelected(t)
ROUTE_TOGGLE        = lambda src, dst: mixer.setRouteTo(src, dst, -1)
ROUTE_REMOVE_MASTER = lambda src: mixer.setRouteTo(src, 0, 0)
ROUTING_CHANGED     = lambda: mixer.afterRoutingChanged()

# === FADERS ===
FADER_M_GET = lambda p: mixer.getTrackVolume(0)
FADER_M_SET = lambda p, v: mixer.setTrackVolume(0, v)
FADER_GET   = lambda dt: mixer.getTrackVolume(dt.TrackNum)
FADER_SET   = lambda dt, v: mixer.setTrackVolume(dt.TrackNum, v)

# === TRACK SCRIBBLES ===
NUMBERS_GET  = lambda p, i: f"CH {p['tracks'][i].TrackNum}" # Not +1 for FL
NAME_GET     = lambda p, i: mixer.getTrackName(p['tracks'][i].TrackNum)
COLOR_GET    = lambda p, i: (mixer.getTrackColor(t) if (t := p['tracks'][i].TrackNum) is not None else 0)
TRACK_PAN_GET = lambda p, i: (
    (lambda pan, prefix, pct:
        (f"{prefix}{pct:.1f}%")[:7].ljust(7)
    )(
        pan := mixer.getTrackPan(p["tracks"][i].TrackNum),
        "C " if abs(pan) < 0.005 else ("L " if pan < 0 else "R "),
        abs(pan) * 100.0
    )
)
TRACK_DB_GET = lambda p, i: (
    (lambda db:
        "-inf dB" if db <= -90.0 else f"{db:.1f}dB"
    )(
        mixer.getTrackVolume(p["tracks"][i].TrackNum, 1)
    )
)



# === SELECT ===
SELECT_GET = lambda p, i: ((t := p['tracks'][i].TrackNum) is not None and mixer.trackNumber() == t)
SELECT_SET = lambda p, i: (mixer.setTrackNumber(t.TrackNum) if (t := p["tracks"][i]).TrackNum is not None else None)
# RECEIEVE MODE
SELECT_TOGGLE = lambda dt: (mixer.selectTrack(dt.TrackNum, not mixer.isTrackSelected(dt.TrackNum)))
IS_SELECTED   = lambda dt: mixer.isTrackSelected(dt.TrackNum)

# === MSR: MUTE / SOLO ===
MUTE_GET = lambda p, i: (0 <= i < len(p["tracks"]) and (tn := p["tracks"][i].TrackNum) is not None and 0 <= tn < p["mixer"].trackCount() and p["mixer"].isTrackMuted(tn))
MUTE_SET = lambda p, i, s: (p["mixer"].enableTrack(t) if ((t := p["tracks"][i].TrackNum) is not None and bool(s) != (not p["mixer"].isTrackEnabled(t))) else None)
SOLO_GET = lambda p, i: (0 <= i < len(p["tracks"]) and (tn := p["tracks"][i].TrackNum) is not None and 0 <= tn < p["mixer"].trackCount() and p["mixer"].isTrackSolo(tn))
SOLO_SET = lambda p, i, s: (p["mixer"].soloTrack(t, p["midi"].fxSoloToggle) if ((t := p["tracks"][i].TrackNum) is not None and p["mixer"].isTrackSolo(t) != bool(s)) else None)
ARM_GET  = lambda p, i: (0 <= i < len(p["tracks"]) and (tn := p["tracks"][i].TrackNum) is not None and 0 <= tn < p["mixer"].trackCount() and p["mixer"].isTrackArmed(tn))
ARM_SET  = lambda p, i, s: ((lambda tn, mix, state: mix.armTrack(tn) if mix.isTrackArmed(tn) != bool(state) else None)(tn, p["mixer"], s)) if 0 <= i < len(p["tracks"]) and (tn := p["tracks"][i].TrackNum) is not None else None

# === ROUTING / BUSES ===
SENDS_GET = lambda p, i: (f"Bus: {sum(1 for d in range(p['mixer'].trackCount()) if p['mixer'].getRouteSendActive(p['tracks'][i].TrackNum, d))}")
SENDNAMES_GET = lambda p, i: ((lambda mix, tnum: (lambda active: "None" if not active else mix.getTrackName(active[0]) if len(active) == 1 else "VARIOUS")([d for d in range(mix.trackCount()) if mix.getRouteSendActive(tnum, d)]))(p["mixer"], p["tracks"][i].TrackNum))

# === TRANSPORT ===
PLAY         = lambda p: transport.start()
STOP         = lambda p: transport.stop()
IS_PLAYING   = lambda p: transport.isPlaying()
ANY_ARMED    = lambda p: any( p["mixer"].isTrackArmed(tn) for t in p["tracks"] if (tn := t.TrackNum) is not None and tn < p["mixer"].trackCount())
ARM_SEL_TGL  = lambda p: p["mixer"].armTrack(p["mixer"].trackNumber())
IS_ARMED_SEL = lambda p: (p["mixer"].isTrackArmed(tn) if (tn := p["mixer"].trackNumber()) is not None else False)
TIME_GET     = lambda p: p["transport"].getSongPos(2)
TIME_SET     = lambda p, v: p["transport"].setSongPos(float(v), 2)
TIME_ADD     = lambda p, d: p["transport"].setSongPos(p["transport"].getSongPos(2) + float(d),2)
# === LOOP / PUNCH STATE (MODULE-LEVEL; PERSISTS) ===
IS_LOOP  = lambda p: transport.getLoopMode() == 0
_loop_stage = 0
def LOOP_TGL(p):
    global _loop_stage
    PME = 111
    if _loop_stage == 0:
        transport.globalTransport(midi.FPT_PunchIn, 1, PME)
        _loop_stage = 1
        return "Loop In"
    elif _loop_stage == 1:
        transport.globalTransport(midi.FPT_PunchOut, 1, PME)
        transport.globalTransport(midi.FPT_Punch,    1, PME)
        _loop_stage = 2
        return "LoopOut"
    else:
        transport.globalTransport(midi.FPT_Punch, 0, PME)
        _loop_stage = 0
        return "LoopOff"

# === METERS 0–7 ===
METER_MSG    = lambda status, data1: (status, data1)
METER_GET    = lambda p, i: (lambda t: mixer.getTrackPeaks(t.TrackNum, midi.PEAK_LR_INV) if t else 0.0)(TRACK_LIVE(p, i))
METER_M_INIT = lambda p: None
METER_M_GET  = lambda p: (float(mixer.getTrackPeaks(0, midi.PEAK_L)),float(mixer.getTrackPeaks(0, midi.PEAK_R)))
METER_M_MSG  = lambda status, lvlL, lvlR: ((status, (lvlL & 0x0F)),(status, ((lvlR & 0x0F) | 0x10)))
MASTER_GET   = lambda p: float(max(mixer.getTrackPeaks(0, midi.PEAK_L),mixer.getTrackPeaks(0, midi.PEAK_R)))

# === BUTTONS ===
SET_DAWTRACK_COLOR = lambda dt, rgb_int: mixer.setTrackColor(dt.TrackNum,int(rgb_int))
SET_DAWTRACK_NAME  = lambda dt, name: mixer.setTrackName(dt.TrackNum,str(name))
MARKER_TGL         = lambda p: transport.globalTransport(midi.FPT_AddMarker, 1)
MARKER_PREV        = lambda p: transport.globalTransport(midi.FPT_MarkerJumpJog, -1)
MARKER_NEXT        = lambda p: transport.globalTransport(midi.FPT_MarkerJumpJog, 1)
UNDO               = lambda p: general.undoUp()
REDO               = lambda p: general.undoDown()
METRONOME          = lambda p: transport.globalTransport(midi.FPT_Metronome, 1)
COUNTDOWN          = lambda p: transport.globalTransport(midi.FPT_CountDown, 1)
SONG_PATTERN       = lambda p: transport.globalTransport(midi.FPT_Loop, 1)
METRONOME_GET      = lambda p: ui.isMetronomeEnabled()
COUNTDOWN_GET      = lambda p: ui.isPrecountEnabled()
LOOP_GET           = lambda p: transport.getLoopMode()

# === WINDOWS ===
PLAYLIST_GET      = lambda p: ui.getVisible(midi.widPlaylist)
PLAYLIST_SET      = lambda p: ui.showWindow(midi.widPlaylist)
PIANOROLL_GET     = lambda p: ui.getVisible(midi.widPianoRoll)
PIANOROLL_SET     = lambda p: ui.showWindow(midi.widPianoRoll)
RACK_GET          = lambda p: ui.getVisible(midi.widChannelRack)
RACK_SET          = lambda p: ui.showWindow(midi.widChannelRack)
MIXER_GET         = lambda p: ui.getVisible(midi.widMixer)
MIXER_SET         = lambda p: ui.showWindow(midi.widMixer)
BROWSER_GET       = lambda p: ui.getVisible(midi.widBrowser)
BROWSER_SET       = lambda p: ui.showWindow(midi.widBrowser)
PLAYLIST_TOGGLE   = lambda p: (ui.hideWindow(midi.widPlaylist)  if ui.getVisible(midi.widPlaylist)  else ui.showWindow(midi.widPlaylist))
PIANOROLL_TOGGLE  = lambda p: (ui.hideWindow(midi.widPianoRoll) if ui.getVisible(midi.widPianoRoll) else ui.showWindow(midi.widPianoRoll))
RACK_TOGGLE       = lambda p: (ui.hideWindow(midi.widChannelRack) if ui.getVisible(midi.widChannelRack) else ui.showWindow(midi.widChannelRack))
MIXER_TOGGLE      = lambda p: (ui.hideWindow(midi.widMixer)     if ui.getVisible(midi.widMixer)     else ui.showWindow(midi.widMixer))
BROWSER_TOGGLE    = lambda p: (ui.hideWindow(midi.widBrowser)   if ui.getVisible(midi.widBrowser)   else ui.showWindow(midi.widBrowser))
CLOSE_ALL_WINDOWS = lambda p: (ui.hideWindow(midi.widPlaylist),ui.hideWindow(midi.widPianoRoll),ui.hideWindow(midi.widChannelRack),ui.hideWindow(midi.widMixer),ui.hideWindow(midi.widBrowser))

# === PLUGIN MODE ===
PLUGIN_COUNT_GET       = lambda p: sum(1 for i in range(10) if plugins.isValid(mixer.trackNumber(), i)) # Not needed?
PLUGIN_NAME_GET        = (lambda p, j: plugins.getPluginName(mixer.trackNumber(), int(j)) if (0 <= int(j) <= 9 and plugins.isValid(mixer.trackNumber(), int(j))) else "")
PLUGIN_WET_GET         = (lambda p, DT, SLOT: float(mixer.getPluginMixLevel(int(getattr(DT, "TrackNum", DT)), SLOT)) if 0 <= int(SLOT) <= 9 else 0.0)
PLUGIN_WET_SET         = (lambda p, DT, SLOT, value: mixer.setPluginMixLevel(int(getattr(DT, "TrackNum", DT)),int(SLOT),float(value)) if 0 <= int(SLOT) <= 9 else None)
DEVICE_SELECT_AT       = lambda p, j: ((globals().__setitem__("_SELECTED_PLUGIN_TRACK", mixer.trackNumber()) or globals().__setitem__("_SELECTED_PLUGIN_SLOT", int(j)) or mixer.focusEditor(mixer.trackNumber(), int(j)) or True)if (isinstance(j, (int, str)) and 0 <= int(j) <= 9 and plugins.isValid(mixer.trackNumber(), int(j)))else False)
SELECTED_PLUGIN_SLOT   = lambda p: _SELECTED_PLUGIN_SLOT
SELECTED_PLUGIN_TRACK  = lambda p: _SELECTED_PLUGIN_TRACK
PLUGIN_PARAM_COUNT_GET = lambda payload: (plugins.getParamCount(int(_SELECTED_PLUGIN_TRACK),int(_SELECTED_PLUGIN_SLOT))if (_SELECTED_PLUGIN_TRACK >= 0 and _SELECTED_PLUGIN_SLOT >= 0)else 0)
PLUGIN_PARAM_VALUE_GET = lambda payload, param_index: (plugins.getParamValue(int(param_index),int(_SELECTED_PLUGIN_TRACK),int(_SELECTED_PLUGIN_SLOT))if (_SELECTED_PLUGIN_TRACK >= 0 and _SELECTED_PLUGIN_SLOT  >= 0 and param_index < plugins.getParamCount(int(_SELECTED_PLUGIN_TRACK),int(_SELECTED_PLUGIN_SLOT)))else "")
PLUGIN_PARAM_VALUE_SET = lambda payload, param_index, value: (plugins.setParamValue(float(value),int(param_index),int(_SELECTED_PLUGIN_TRACK),int(_SELECTED_PLUGIN_SLOT))if (_SELECTED_PLUGIN_TRACK >= 0 and _SELECTED_PLUGIN_SLOT  >= 0 and param_index < plugins.getParamCount(int(_SELECTED_PLUGIN_TRACK),int(_SELECTED_PLUGIN_SLOT)))else False)
PLUGIN_PARAM_NAME_GET  = lambda payload, param_index: (plugins.getParamName(int(param_index),int(_SELECTED_PLUGIN_TRACK), int(_SELECTED_PLUGIN_SLOT)) if (_SELECTED_PLUGIN_TRACK >= 0 and _SELECTED_PLUGIN_SLOT  >= 0 and param_index < plugins.getParamCount( int(_SELECTED_PLUGIN_TRACK),int(_SELECTED_PLUGIN_SLOT))) else "")

# === EQ MODE ===
EQ_GAIN_GET      = lambda payload, band: (mixer.getEqGain(mixer.trackNumber(),int(band)))
EQ_GAIN_SET      = lambda payload, band, value: (mixer.setEqGain(mixer.trackNumber(),int(band),float(value)))
EQ_FREQ_GET      = lambda payload, band: (mixer.getEqFrequency(mixer.trackNumber(),int(band))if 0 <= int(band) <= 2 else 0.0)
EQ_FREQ_SET      = lambda payload, band, value: (mixer.setEqFrequency(mixer.trackNumber(),int(band),float(value))if 0 <= int(band) <= 2 else False)
EQ_BANDWIDTH_GET = lambda payload, band: (mixer.getEqBandwidth(mixer.trackNumber(),int(band))if 0 <= int(band) <= 2 else 0.0)
EQ_BANDWIDTH_SET = lambda payload, band, value: (mixer.setEqBandwidth(mixer.trackNumber(),int(band),float(value))if 0 <= int(band) <= 2 else False)

# === EQ2 MODE ===
HAS_EQ2 = lambda payload: any(plugins.isValid(mixer.trackNumber(), slot) and "fruity parametric eq 2" in plugins.getPluginName(mixer.trackNumber(), slot, 0).lower() for slot in range(10))
EQ2_SLOT = lambda payload: next(((mixer.focusEditor(mixer.trackNumber(), slot), slot)[1] for slot in range(10) if plugins.isValid(mixer.trackNumber(), slot) and "fruity parametric eq 2" in plugins.getPluginName(mixer.trackNumber(), slot, 0).lower()),-1)
EQ2_PARAM_GET = lambda payload, param_index: (plugins.getParamValue(int(param_index),mixer.trackNumber(),EQ2_SLOT(payload)) if HAS_EQ2(payload) else None)
EQ2_PARAM_SET = lambda payload, param_index, value: (plugins.setParamValue(float(value),int(param_index),mixer.trackNumber(),EQ2_SLOT(payload)) if HAS_EQ2(payload) else False)
