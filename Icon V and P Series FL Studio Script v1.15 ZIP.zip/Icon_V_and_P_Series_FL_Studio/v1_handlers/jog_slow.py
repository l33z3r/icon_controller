def adjust(payload):
    # PAYLOAD IMPORTS
    D2 = payload.get("data2")
    DM  = payload.get("daw_map")

    # CALCULATIONS
    DIR = -1 if D2 >= 64 else 1 # 0–63 forward, 64–127 backward
    STEP = 96
    CUR = DM.CURRENT_SONGPOS(payload)  # current position in seconds
    NEW = max(0.0, CUR + (DIR * STEP))

    # SEND: HARDWARE → DAW
    DM.NEW_SONGPOS(payload, NEW)
