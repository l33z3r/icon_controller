import ui
import playlist

# === HELPERS ===
_cache = ['\0'] * 10

def format_time_string():
    if ui.getTimeDispMin():
        # Time mode (MM:SS:CC)
        minutes = abs(playlist.getVisTimeBar())
        seconds = abs(playlist.getVisTimeStep())
        centis  = abs(playlist.getVisTimeTick())
        return f"{str(minutes).rjust(4)}:{seconds:02d}:{centis:02d}"[:10]
    else:
        # Beats mode (BBBB:SS:TT)
        bars  = abs(playlist.getVisTimeBar())
        steps = abs(playlist.getVisTimeStep())
        ticks = abs(playlist.getVisTimeTick())
        return f"{str(bars).rjust(4)}:{steps:02d}:{ticks:02d}"[:10]

# === REFRESH: DAW → HARDWARE ===
def refresh(payload):
    DM = payload["daw_map"]
    AD = payload["addr"]

    TEXT = format_time_string()
    msg  = (TEXT or "").ljust(10)[:10]

    for i, ch in enumerate(msg):
        if _cache[i] != ch:
            DM.SEND_DAW(
                payload,
                (0xB0, AD.CLOCK_DISPLAY[i], ord(ch) & 0x7F)
            )
            _cache[i] = ch


# === ONIDLE CONTROL ===
tick = refresh

# === RESET: DAW → HARDWARE ===
def reset(payload):
    DM = payload["daw_map"]
    AD = payload["addr"]

    for i, cc in enumerate(AD.CLOCK_DISPLAY):  # expects 10 CCs
        DM.SEND_DAW(
            payload,
            (0xB0, cc, ord(' ') & 0x7F)
        )
        _cache[i] = ' '
