def adjust(payload):
    D2 = payload.get("data2")
    DM = payload["daw_map"]

    DIR = -1 if D2 >= 64 else 1  # back/forward
    DM.SNAP(DIR)
