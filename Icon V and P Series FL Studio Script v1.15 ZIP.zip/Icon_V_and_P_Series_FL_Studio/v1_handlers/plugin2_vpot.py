from v1_handlers.plugin2_page import current_page

PAGE_WIDTH = 8
def _slot_index(payload, in_idx: int) -> int:
    page = int(payload.get("plugin2_page", current_page()))
    return page * PAGE_WIDTH + int(in_idx)

# === ADJUST: HARDWARE → DAW (Hardware CH 0–7)
def adjust(payload):
    # PAYLOAD IMPORTS
    D1 = payload["data1"]
    D2 = payload["data2"]
    DM = payload["daw_map"]
    AD = payload["addr"]

    # CALCULATIONS
    OS   = D1 - AD.PAN1_OS
    SLOT = _slot_index(payload, OS)

    POS1 = DM.PLUGIN_PARAM_VALUE_GET(payload, SLOT)
    if not isinstance(POS1, float):
        return
    DIR  = -1.0 if (D2 & AD.PAN_DIR) else 1.0
    STEP = 0.05
    POS2 = float(POS1) + (DIR * STEP)
    CLAMP = max(0.0, min(1.0, POS2))

    # SEND: HARDWARE → DAW
    DM.PLUGIN_PARAM_VALUE_SET(payload, SLOT, CLAMP)

# === PRESS: HARDWARE (Hardware CH 0–7)
def press(payload):
    # PAYLOAD IMPORTS
    DM = payload["daw_map"]
    AD = payload["addr"]
    D1 = int(payload["data1"])

    # CALCULATIONS
    i = D1 - AD.PAN2_OS
    j = i

    from v1_core.shared_mode_buffer import shared as shared_mode
    from v1_core import refresher, mode_manager
    from v1_handlers import plugin2_page

    # SEND: HARDWARE → HARDWARE
    shared_mode.set_mode("plugin_mode")
    refresher.on_mode_changed(payload)
    mode_manager.refresh(payload)
    plugin2_page.reset()

# === REFRESH: DAW → HARDWARE (Hardware CH 0–7)
def refresh(payload):
    # PAYLOAD IMPORTS
    DM = payload["daw_map"]
    AD = payload["addr"]

    MODE = AD.MODE_DOT << 4
    CC   = AD.VPOT_CC

    # CALCULATIONS
    for i in range(8):
        D1   = AD.VPOT_OS + i
        SLOT = _slot_index(payload, i)

        level = DM.PLUGIN_PARAM_VALUE_GET(payload, SLOT)

        if isinstance(level, float):
            POS = max(1, min(int(level * 11) + 1, 11))
        else:
            POS = 0

        D2 = MODE | POS

        # SEND: DAW → HARDWARE
        DM.SEND_DAW(payload, DM._3_BYTE_MSG(CC, D1, D2))
