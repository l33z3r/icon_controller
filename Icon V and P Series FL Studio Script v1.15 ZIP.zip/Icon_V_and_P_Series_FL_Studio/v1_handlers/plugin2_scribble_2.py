from v1_handlers.plugin2_page import current_page

PAGE_WIDTH = 8
def _slot_index(payload, in_idx: int) -> int:
    page = int(payload.get("plugin2_page", current_page()))
    return page * PAGE_WIDTH + int(in_idx)

# === REFRESH: DAW → HARDWARE (Hardware CH 0–7)
def refresh(payload):
    DM = payload["daw_map"]
    AD = payload["addr"]

    VALUES = [
        DM.PLUGIN_PARAM_VALUE_GET(payload, _slot_index(payload, i))
        for i in range(8)
    ]

    CELLS = [
        (("{:.3f}".format(v)) if isinstance(v, float) else "").ljust(7)[:7]
        for v in VALUES
    ]

    text  = ''.join(CELLS)[:56].ljust(56)
    sysex = bytearray(AD.SCRIBBLE_2)
    sysex.extend(text.encode('ascii', 'replace'))
    sysex.append(0xF7)

    DM.SEND_DAW(payload, tuple(sysex))
