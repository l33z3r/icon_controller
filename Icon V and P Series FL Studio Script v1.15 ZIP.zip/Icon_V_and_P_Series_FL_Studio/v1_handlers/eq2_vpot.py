from v1_handlers.eq2_page import current_page

EQ2_FREQ_PARAMS = [7, 8, 9, 10, 11, 12, 13]
EQ2_Q_PARAMS    = [14, 15, 16, 17, 18, 19, 20]
EQ2_GAIN_PARAMS = [35, 0, 1, 2, 3, 4, 5, 6]
freq_vals = [0.166671752929687,0.27777099609375,0.388885498046875,0.5,0.611114501953125,0.72222900390625,0.833328247070312]
q_vals = [0.61224365234375,0.38775634765625,0.38775634765625,0.38775634765625,0.38775634765625,0.38775634765625,0.61224365234375]

# === ADJUST: HARDWARE → DAW (VPOT CH 0–7)
def adjust(payload):
    D1 = payload["data1"]
    D2 = payload["data2"]
    DM = payload["daw_map"]
    AD = payload["addr"]

    i = D1 - AD.PAN1_OS

    # VPOT 0 ignored, VPOTs 1–7 only
    if i < 1 or i > 7:
        return

    band = i - 1  # VPOT 1–7 → bands 0–6
    use_q = (current_page() == 1)
    param_map = EQ2_Q_PARAMS if use_q else EQ2_FREQ_PARAMS
    param_index = param_map[band]
    cur = DM.EQ2_PARAM_GET(payload, param_index)
    if not isinstance(cur, float):
        return

    DIR   = -1.0 if (D2 & AD.PAN_DIR) else 1.0
    STEP  = 0.05
    value = max(0.0, min(1.0, cur + DIR * STEP))

    DM.EQ2_PARAM_SET(payload, param_index, value)

# === PRESS: HARDWARE (VPOT CH 0–7) — RESET
def press(payload):
    DM = payload["daw_map"]
    AD = payload["addr"]

    i = payload["data1"] - AD.PAN2_OS
    if i < 1 or i > 7:
        return
    band = i - 1
    use_q = (current_page() == 1)

    if use_q:
        DM.EQ2_PARAM_SET(payload, EQ2_Q_PARAMS[band], q_vals[band])
    else:
        DM.EQ2_PARAM_SET(payload, EQ2_FREQ_PARAMS[band], freq_vals[band])
    gain_param = EQ2_GAIN_PARAMS[i]
    DM.EQ2_PARAM_SET(payload, gain_param, 0.5)

# === REFRESH: DAW → HARDWARE (VPOT CH 0–7)
def refresh(payload):
    DM = payload["daw_map"]
    AD = payload["addr"]

    MODE = AD.MODE_DOT << 4
    PDPV = 10
    use_q = (current_page() == 1)
    param_map = EQ2_Q_PARAMS if use_q else EQ2_FREQ_PARAMS

    for i in range(8):
        CC = AD.VPOT_CC
        D1 = AD.VPOT_OS + i

        # VPOT 0 blank
        if i == 0:
            DM.SEND_DAW(payload, DM._3_BYTE_MSG(CC, D1, 0x00))
            continue

        band = i - 1
        if band < 0 or band > 6:
            DM.SEND_DAW(payload, DM._3_BYTE_MSG(CC, D1, 0x00))
            continue

        val = DM.EQ2_PARAM_GET(payload, param_map[band])
        if not isinstance(val, float):
            DM.SEND_DAW(payload, DM._3_BYTE_MSG(CC, D1, 0x00))
            continue

        pos = int(max(0.0, min(1.0, val)) * PDPV + 0.5)
        DM.SEND_DAW(payload, DM._3_BYTE_MSG(CC, D1, MODE | (1 + pos)))
