# === ADJUST: HARDWARE → DAW (Hardware CH 0–7)
def adjust(payload):
    # PAYLOAD IMPORTS
    D1 = payload["data1"]
    D2 = payload["data2"]
    HT = payload["tracks"]
    DM = payload["daw_map"]
    AD = payload["addr"]
    TT = payload["temp_text"]

    # CALCULATIONS
    OS = D1 - AD.PAN1_OS
    DT = DM.DAW_TRACK(HT[OS])
    LVL1 = DM.SEND_GET(payload, DT)
    DIR  = -1.0 if (D2 & AD.PAN_DIR) else 1.0
    STEP = 0.05
    LVL2 = LVL1 + (DIR * STEP)
    LVL2 = max(0.0, min(1.0, LVL2))

    # SEND: DAW → HARDWARE
    DM.SEND_SET(payload, DT, LVL2)
    refresh(payload)

# === REFRESH: DAW → HARDWARE (Hardware CH 0–7)
def refresh(payload):
    # PAYLOAD IMPORTS
    HT = payload["tracks"]
    DM = payload["daw_map"]
    AD = payload["addr"]

    # CALCULATIONS
    MODE = AD.MODE_DOT << 4
    CC   = AD.VPOT_CC
    for i in range(8):
        D1 = AD.VPOT_OS + i
        DT = DM.DAW_TRACK(HT[i])
        if not DM.HAS_AUDIO(payload, i) or not DM.SEND_ACTIVE(payload, DT):
            DM.SEND_DAW(payload, DM._3_BYTE_MSG(CC, D1, 0x00))
            continue
        level = DM.SEND_GET(payload, DT)
        POS = max(1, min(round(level * 10) + 1, 11))
        D2  = MODE | POS

        # SEND: HARDWARE → DAW
        DM.SEND_DAW(payload, DM._3_BYTE_MSG(CC, D1, D2))

# === PRESS: HARDWARE (Toggle Roting)
def press(payload):
    # PAYLOAD IMPORTS
    DM = payload["daw_map"]
    AD = payload["addr"]
    TT = payload["temp_text"]
    HT = payload["tracks"]
    D1 = payload["data1"]

    # CALCULATIONS
    OS = D1 - AD.PAN2_OS
    DT = DM.DAW_TRACK(HT[OS])

    # SEND: HARDWARE → DAW
    state = DM.SEND_TOGGLE(payload, DT)
    TT.SHOW_TEMP(OS, "Route:", "On" if state else "Off")
    refresh(payload)
