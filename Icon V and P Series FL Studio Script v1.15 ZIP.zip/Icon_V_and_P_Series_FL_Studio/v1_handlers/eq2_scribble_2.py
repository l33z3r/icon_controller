# === REFRESH: DAW → HARDWARE (Hardware CH 0–7)
def refresh(payload):
    DM = payload["daw_map"]
    AD = payload["addr"]

    row_labels = [
        "Level  ",
        "Gain 1 ",
        "Gain 2 ",
        "Gain 3 ",
        "Gain 4 ",
        "Gain 5 ",
        "Gain 6 ",
        "Gain 7 ",
    ]

    CELLS = [s.ljust(7)[:7] for s in row_labels]

    # CALCULATIONS (Build SysEx row exactly 56 chars)
    text  = ''.join(CELLS)[:56].ljust(56)
    sysex = bytearray(AD.SCRIBBLE_2)
    sysex.extend(text.encode("ascii", "replace"))
    sysex.append(0xF7)

    # SEND: DAW → HARDWARE
    DM.SEND_DAW(payload, tuple(sysex))
