_BLOCK_REFRESH = False

# === ADJUST: HARDWARE → DAW (Hardware CH 0–7)
def adjust(payload):
    # PAYLOAD IMPORTS
    d1 = payload["data1"]
    d2 = payload["data2"]
    OS = payload["midiChan"]
    HT = payload["tracks"]
    DM = payload["daw_map"]
    AD = payload["addr"]

    if OS > 2: # ONLY FADERS 0–2 (EQ bands)
        return

    # HARDWARE RESOLUTION
    DPV = 16383.0

    # CALCULATIONS
    DT    = DM.DAW_TRACK(HT[OS])
    D1    = (d1 & 0x7F)
    D2    = (d2 & 0x7F) << 7
    VALUE = (D1 | D2)
    POS   = VALUE / DPV
    CLAMP = max(0.0, min(1.0, POS))

    # SEND: HARDWARE → DAW
    DM.EQ_GAIN_SET(payload, OS, CLAMP)

# === REFRESH: DAW → HARDWARE (Hardware CH 0–7)
def refresh(payload):
    # PAYLOAD IMPORTS
    HT = payload["tracks"]
    DM = payload["daw_map"]
    AD = payload["addr"]

    FDPV = 16383.0

    # CALCULATIONS
    for i in range(8):
        OS = AD.PITCH_BEND_OS + i

        if i > 2:
            DM.SEND_DAW(payload, DM._3_BYTE_MSG(OS, 0, 0))
            continue

        VALUE = DM.EQ_GAIN_GET(payload, i)
        CLAMP = max(0.0, min(1.0, float(VALUE)))
        POS = int(CLAMP * FDPV + 0.5)
        D1  = POS & 0x7F
        D2  = (POS >> 7) & 0x7F

        # SEND: DAW → HARDWARE
        DM.SEND_DAW(payload, DM._3_BYTE_MSG(OS, D1, D2))
