# === REFRESH: DAW → HARDWARE (Hardware CH 0–7)
def refresh(payload):
    DM = payload["daw_map"]
    AD = payload["addr"]

    # If EQ2 is NOT present on the selected track → blank row
    if not DM.HAS_EQ2(payload):
        print("[EQ2] NOT PRESENT → blanking COLOR_ROW")

        sysex = bytearray(AD.COLOR_ROW)
        for _ in range(8):
            sysex.extend((0, 0, 0))
        sysex.append(0xF7)

        DM.SEND_DAW(payload, tuple(sysex))
        return

    # === EQ BAND COLOURS (8-bit RGB) ===
    rgb_8bit = [
        (0,   0,   0),     # 0 – unused
        (148, 60, 255),    # 1 – Band 1 (Purple)
        (255, 60, 165),    # 2 – Band 2 (Pink)
        (255, 90, 60),     # 3 – Band 3 (Coral)
        (255, 200, 60),    # 4 – Band 4 (Yellow)
        (60, 255, 60),     # 5 – Band 5 (Green)
        (60, 255, 200),    # 6 – Band 6 (Teal)
        (60, 90, 255),     # 7 – Band 7 (Blue)
    ]

    # Convert to 7-bit SysEx-safe (0–127)
    rgb_7bit = [(r >> 1, g >> 1, b >> 1) for (r, g, b) in rgb_8bit]

    # Build SysEx (address + 8×RGB + F7)
    sysex = bytearray(AD.COLOR_ROW)
    for r7, g7, b7 in rgb_7bit:
        sysex.extend((r7, g7, b7))
    sysex.append(0xF7)

    DM.SEND_DAW(payload, tuple(sysex))
