EQ2_GAIN_PARAMS = [35, 0, 1, 2, 3, 4, 5, 6]

# === ADJUST: HARDWARE → DAW (Hardware CH 0–7)
def adjust(payload):
    d1 = payload["data1"]
    d2 = payload["data2"]
    OS = payload["midiChan"]     # fader index 0–7
    DM = payload["daw_map"]

    if OS < 0 or OS > 7:
        return

    param_index = EQ2_GAIN_PARAMS[OS]
    value = ((d1 & 0x7F) | ((d2 & 0x7F) << 7)) / 16383.0
    value = max(0.0, min(1.0, value))

    DM.EQ2_PARAM_SET(payload, param_index, value)

# === REFRESH: DAW → HARDWARE (Hardware CH 0–7)
def refresh(payload):
    DM = payload["daw_map"]
    AD = payload["addr"]

    FDPV = 16383.0

    # CALCULATIONS
    for i in range(8):
        OS = AD.PITCH_BEND_OS + i

        param_index = EQ2_GAIN_PARAMS[i]
        VALUE = DM.EQ2_PARAM_GET(payload, param_index)

        if not isinstance(VALUE, float):
            DM.SEND_DAW(payload, DM._3_BYTE_MSG(OS, 0, 0))
            continue

        CLAMP = max(0.0, min(1.0, VALUE))
        POS   = int(CLAMP * FDPV + 0.5)
        D1    = POS & 0x7F
        D2    = (POS >> 7) & 0x7F

        # SEND: DAW → HARDWARE
        DM.SEND_DAW(payload, DM._3_BYTE_MSG(OS, D1, D2))
