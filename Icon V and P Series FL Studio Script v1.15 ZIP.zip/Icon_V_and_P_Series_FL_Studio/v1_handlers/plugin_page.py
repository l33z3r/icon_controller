_PAGE  = 0
_CLAMP = 2

def _calc_clamp(payload):
    return 2

def set_clamp(n: int):
    global _CLAMP, _PAGE
    _CLAMP = 2
    if _PAGE >= _CLAMP:
        _PAGE = _CLAMP - 1

def current_page() -> int:
    return _PAGE

def current_clamp() -> int:
    return _CLAMP

def reset():
    global _PAGE
    _PAGE = 0

# === PRESS ===
def press(payload):
    global _PAGE
    RE = payload["refresher"]
    D1 = payload["data1"]

    set_clamp(2)
    if   D1 == 0x2C and _PAGE < _CLAMP - 1: _PAGE += 1
    elif D1 == 0x2D and _PAGE > 0:          _PAGE -= 1

    RE.on_page_changed(payload)
