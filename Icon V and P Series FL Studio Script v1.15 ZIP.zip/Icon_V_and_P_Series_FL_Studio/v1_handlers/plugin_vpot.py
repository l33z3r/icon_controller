from v1_handlers.plugin_page import current_page

PAGE_WIDTH = 8

def _slot_index(payload, in_idx: int) -> int:
    return (current_page() * PAGE_WIDTH) + int(in_idx)

# === ADJUST: HARDWARE → DAW (Hardware CH 0–7)
def adjust(payload):
    # PAYLOAD IMPORTS
    D1 = payload["data1"]
    D2 = payload["data2"]
    HT = payload["tracks"]
    DM = payload["daw_map"]
    AD = payload["addr"]
    TT = payload["temp_text"]

    # CALCULATIONS
    OS   = D1 - AD.PAN1_OS
    DT   = DM.GET_DAWTRACK(payload)
    SLOT = _slot_index(payload, OS)
    if SLOT > 9:
        return
    POS1 = DM.PLUGIN_WET_GET(payload, DT, SLOT)
    DIR  = -1.0 if (D2 & AD.PAN_DIR) else 1.0
    STEP = 0.05
    POS2 = float(POS1) + (DIR * STEP)
    CLAMP = max(0, min(1.0, POS2))

    # SEND: HARDWARE → DAW
    DM.PLUGIN_WET_SET(payload, DT, SLOT, CLAMP)
    TT.SHOW_TEMP(OS, "Mix Lv:", DM.WET_TXT(payload, DT, SLOT))

# === PRESS: HARDWARE (Hardware CH 0–7)
def press(payload):
    # PAYLOAD IMPORTS
    DM = payload["daw_map"]
    AD = payload["addr"]
    D1 = int(payload["data1"])

    # CALCULATIONS
    i = D1 - AD.PAN2_OS
    j = _slot_index(payload, i)

    if not DM.DEVICE_SELECT_AT(payload, j):
        return  # EMPTY SLOT → DO NOTHING

    from v1_core.shared_mode_buffer import shared as shared_mode
    from v1_core import refresher, mode_manager

    shared_mode.set_mode("plugin2_mode")
    refresher.on_mode_changed(payload)
    mode_manager.refresh(payload)

# === REFRESH: DAW → HARDWARE (Hardware CH 0–7)
def refresh(payload):
    DM = payload["daw_map"]
    AD = payload["addr"]

    MODE = AD.MODE_DOT << 4
    CC   = AD.VPOT_CC

    for i in range(8):
        D1   = AD.VPOT_OS + i
        DT   = DM.GET_DAWTRACK(payload)     # Selected FL track only
        SLOT = _slot_index(payload, i)      # Paged slot

        if SLOT < 0 or SLOT > 9:
            DM.SEND_DAW(payload, DM._3_BYTE_MSG(CC, D1, 0x00))
            continue

        level = DM.PLUGIN_WET_GET(payload, DT, SLOT)

        POS = max(1, min(round(level * 10) + 1, 11))
        D2  = MODE | POS

        DM.SEND_DAW(payload, DM._3_BYTE_MSG(CC, D1, D2))
