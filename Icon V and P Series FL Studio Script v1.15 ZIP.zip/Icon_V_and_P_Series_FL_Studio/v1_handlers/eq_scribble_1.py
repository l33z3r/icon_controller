# === REFRESH: DAW → HARDWARE (Hardware CH 0–7)
def refresh(payload):
    DM = payload["daw_map"]
    AD = payload["addr"]

    LABELS = [
        "L GAIN ",
        "M GAIN ",
        "H GAIN ",
        "",
        "",
        "",
        "",
        "",
    ]

    CELLS = [s.ljust(7)[:7] for s in LABELS]

    text  = ''.join(CELLS)[:56].ljust(56)
    sysex = bytearray(AD.SCRIBBLE_1)
    sysex.extend(text.encode('ascii', 'replace'))
    sysex.append(0xF7)

    DM.SEND_DAW(payload, tuple(sysex))
