def adjust(payload):
    D2 = payload.get("data2")
    DM = payload["daw_map"]
    TT = payload["temp_text"]

    # === DELTA LOGIC ===
    raw = (D2 - 128) if D2 > 63 else D2
    delta = max(-10, min(10, raw * 10))

    # === SEND: HARDWARE → DAW ===
    DM.TEMPO(delta)
    TT.SHOW_TEMP(7,"Tempo:",DM.TEMPO_TXT(payload))
