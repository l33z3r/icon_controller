_PAGE  = 0
_CLAMP = 1

def set_clamp():
    global _CLAMP, _PAGE
    _CLAMP = 2
    if _PAGE >= _CLAMP:
        _PAGE = _CLAMP - 1

def current_page() -> int:
    return _PAGE

def current_clamp() -> int:
    return 2

def reset():
    global _PAGE
    _PAGE = 0

# === PRESS ===
def press(payload):
    global _PAGE
    RE = payload["refresher"]
    D1 = payload["data1"]

    set_clamp()

    if   D1 == 0x2C and _PAGE == 0:  # page up
        _PAGE = 1
    elif D1 == 0x2D and _PAGE == 1:  # page down
        _PAGE = 0

    RE.on_page_changed(payload)
