def adjust(payload):
    # PAYLOAD IMPORTS
    D2 = payload.get("data2")
    DM  = payload.get("daw_map")

    # CALCULATIONS
    DIR = D2 >= 64 # 0–63 forward, 64–127 backward
    STEP = 1         # beats per move (Ableton 4, FL 1)

    # SEND: HARDWARE → DAW
    DM.JUMP_BY(payload, -STEP if DIR else STEP)

def adjust_h(payload):
    # PAYLOAD IMPORTS
    D1 = payload.get("data1")
    D2  = payload.get("data2")
    DM  = payload.get("daw_map")

    # CALCULATIONS
    DIR = (D1 == 0x62) # 62 Left, 63 right
    MOVE = 2 if D2 > 0 else 0

    # SEND: HARDWARE → DAW
    DM.SCROLL(payload,DM.S_L(payload) if DIR else DM.S_R(payload),MOVE)

def adjust_v(payload):
    # PAYLOAD IMPORTS
    D1 = payload.get("data1")
    DM  = payload.get("daw_map")

    # CALCULATIONS
    DIR = (D1 == 0x60) # 60 Up, 61 Down
    MOVE = 2

    # SEND: HARDWARE → DAW
    DM.SCROLL(payload,DM.S_U(payload) if DIR else DM.S_D(payload),MOVE)
