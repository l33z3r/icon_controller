def adjust_h(payload):
    # PAYLOAD IMPORTS
    D1 = payload.get("data1")
    D2  = payload.get("data2")
    DM  = payload.get("daw_map")

    # CALCULATIONS
    DIR = -1 if D1 == 0x62 else 1 # 62 Left, 63 right
    MOVE = DIR * int(D2 > 0)

    # SEND: HARDWARE → DAW
    DM.SCROLL(payload,DM.Z_H(payload),MOVE)

def adjust_v(payload):
    # PAYLOAD IMPORTS
    D1 = payload.get("data1")
    D2  = payload.get("data2")
    DM  = payload.get("daw_map")

    # CALCULATIONS
    DIR = 1 if D1 == 0x60 else -1 # 60 Up, 61 Down
    MOVE = DIR * int(D2 > 0)

    # SEND: HARDWARE → DAW
    DM.SCROLL(payload,DM.Z_V(payload),MOVE)
