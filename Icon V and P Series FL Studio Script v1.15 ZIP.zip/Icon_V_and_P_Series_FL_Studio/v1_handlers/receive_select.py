# === PRESS: HARDWARE → DAW (Hardware CH 0–7)
def press(payload):
    DM  = payload["daw_map"]
    AD  = payload["addr"]
    HT  = payload["tracks"]
    d1  = payload.get("data1")

    index = d1 - AD.SELECT_CC_BASE

    if not DM.HAS_AUDIO(payload, index):
        return

    DT = DM.DAW_TRACK(HT[index])
    DM.SELECT_TOGGLE(DT)
    refresh(payload)

# === REFRESH: DAW → HARDWARE (Hardware CH 0–7)
def refresh(payload):
    DM = payload["daw_map"]
    AD = payload["addr"]
    HT = payload["tracks"]

    values = []

    for i in range(8):
        DT = DM.DAW_TRACK(HT[i])

        selected = DM.IS_SELECTED(DT)

        values.append(127 if selected else 0)

    # SEND LED STATES
    msgs = [(0x90, AD.SELECT_CC_BASE + i, values[i]) for i in range(8)]
    for m in msgs:
        DM.SEND_DAW(payload, m)
