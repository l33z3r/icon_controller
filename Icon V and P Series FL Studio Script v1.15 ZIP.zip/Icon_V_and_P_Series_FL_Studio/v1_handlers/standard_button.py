# === IMPORTS ===
from v1_handlers import standard_clock
from v1_core import switch_manager as SW

# === HELPERS ===
def _rgb(r, g, b): return (r << 16) | (g << 8) | b

COLOR_ONLY = (
    ("Red",      _rgb(255,  80,  80)), ("Orange",   _rgb(255, 140,   0)),
    ("Gold",     _rgb(255, 200,   0)), ("Yellow",   _rgb(255, 255,   0)),
    ("Lime",     _rgb(140, 255,   0)), ("Teal",     _rgb(  0, 200, 100)),
    ("Mint",     _rgb(  0, 255, 170)), ("Peach",    _rgb(255, 180, 120)),
    ("Magenta",  _rgb(255,   0, 170)), ("Pink",     _rgb(255, 100, 180)),
    ("Cyan",     _rgb(  0, 170, 255)), ("Sky",      _rgb( 80, 180, 255)),
    ("Purple",   _rgb(150,  80, 255)), ("Aqua",     _rgb(  0, 200, 200)),
    ("Coral",    _rgb(255, 100, 100)), ("Blue",     _rgb(  0, 100, 255)),
    ("Sand",     _rgb(255, 220, 130)), ("Indigo",   _rgb(120, 120, 255)),
    ("Pastel",   _rgb(200, 200, 255)), ("Neon",     _rgb(255,   0, 255)),
    ("Lilac",    _rgb(180, 120, 200)), ("Rose",     _rgb(255,  80, 120)),
    ("Tan",      _rgb(210, 160, 120)), ("Grey",     _rgb(100, 100, 100)),
)

NAME_COLOR = (
    ("Kick",     _rgb(255,  20,  20)), ("Snare",    _rgb(255, 110,  40)),
    ("Hats",     _rgb(255, 200,   0)), ("Clap",     _rgb(255, 110,  40)),
    ("Perc",     _rgb(255, 255,   0)), ("Sub",      _rgb(  0, 100, 255)),
    ("Bass",     _rgb(  0, 100, 255)), ("Piano",    _rgb(185, 120, 255)),
    ("Lead",     _rgb(185, 120, 255)), ("Synth",    _rgb(185, 120, 255)),
    ("Pad",      _rgb(185, 120, 255)), ("Vox",      _rgb(255, 100, 180)),
    ("Bvox",     _rgb(255, 150, 200)), ("FX",       _rgb(200, 200, 220)),
    ("Impact",   _rgb(200, 200, 220)), ("Amb",      _rgb(200, 200, 220)),
    ("Loop",     _rgb(255, 255,   0)), ("Shaker",   _rgb(255, 255,   0)),
    ("Arp",      _rgb(  0, 130, 255)), ("Strings",  _rgb(185, 120, 255)),
    ("Pluck",    _rgb(185, 120, 255)), ("Harmony",  _rgb(255, 150, 200)),
    ("Crash",    _rgb(200, 200, 220)), ("Fill",     _rgb(200, 200, 220)),
)

# === PRESS: HARDWARE → DAW (Global Buttons)
def press(payload):
    ST = payload.get("status")
    D1 = payload.get("data1")
    D2 = payload.get("data2")
    DM = payload["daw_map"]
    AD = payload["addr"]

    # CLOCK TOGGLE
    if ST == 0x90 and D1 == 0x35 and D2 > 0:
        import ui
        from v1_handlers import standard_clock
        ui.setTimeDispMin()
        standard_clock.refresh(payload)
        value = 127 if ui.getTimeDispMin() else 0
        DM.SEND_DAW(payload, (ST, AD.CLOCK_TOGGLE, value))
        return

    # CHANGE DAW COLOR-ONLY ===
    if ST == 0x92 and D2 > 0 and 0 <= D1 < len(COLOR_ONLY):
        DAWTRACK = DM.GET_DAWTRACK(payload)
        _, RBG = COLOR_ONLY[D1]
        DM.SET_DAWTRACK_COLOR(DAWTRACK, RBG)
        return

    # === CHANGE DAW NAME + COLOR ===
    if ST == 0x91 and D2 > 0 and 0 <= D1 < len(NAME_COLOR):
        DAWTRACK = DM.GET_DAWTRACK(payload)
        NAME, RBG = NAME_COLOR[D1]
        DM.SET_DAWTRACK_NAME(DAWTRACK, NAME)
        DM.SET_DAWTRACK_COLOR(DAWTRACK, RBG)
        return

    # === FLIP MODE ===
    if ST == 0x90 and D1 == 0x32 and D2 > 0:
        SW.toggle("flip", payload)
        refresh(payload)
        return

    # === ADD/DELETE MARKER ===
    if ST == 0x90 and D1 == 0x52 and D2 > 0:
        DM.MARKER_TGL(payload)
        return

    # === PREVIOUS MARKER ===
    if ST == 0x90 and D1 == 0x54 and D2 > 0:
        DM.MARKER_PREV(payload)
        return

    # === NEXT MARKER ===
    if ST == 0x90 and D1 == 0x55 and D2 > 0:
        DM.MARKER_NEXT(payload)
        return

    # === UNDO ===
    if ST == 0x90 and D1 == 0x4C and D2 > 0:
        DM.UNDO(payload)
        return

    # === REDO ===
    if ST == 0x90 and D1 == 0x4F and D2 > 0:
        DM.REDO(payload)
        return

    # === CLOSE WINDOWS ===
    if ST == 0x90 and D1 == 0x7A and D2 > 0:
        DM.CLOSE_ALL_WINDOWS(payload)
        refresh(payload)
        return

    # === PLAYLIST ===
    if ST == 0x90 and D1 == 0x7B and D2 > 0:
        DM.PLAYLIST_TOGGLE(payload)
        refresh(payload)
        return

    # === PIANO ROLL ===
    if ST == 0x90 and D1 == 0x7C and D2 > 0:
        DM.PIANOROLL_TOGGLE(payload)
        refresh(payload)
        return

    # === CHANNEL RACK ===
    if ST == 0x90 and D1 == 0x7D and D2 > 0:
        DM.RACK_TOGGLE(payload)
        refresh(payload)
        return

    # === MIXER ===
    if ST == 0x90 and D1 == 0x7E and D2 > 0:
        DM.MIXER_TOGGLE(payload)
        refresh(payload)
        return

    # === BROWSER ===
    if ST == 0x90 and D1 == 0x7F and D2 > 0:
        DM.BROWSER_TOGGLE(payload)
        refresh(payload)
        return

    # === SONG / PATTERN ===
    if ST == 0x90 and D1 == 0x57 and D2 > 0:
        DM.METRONOME(payload)
        refresh(payload)
        return

    # === METRONOME ===
    if ST == 0x90 and D1 == 0x58 and D2 > 0:
        DM.COUNTDOWN(payload)
        refresh(payload)
        return

    # === 321 ===
    if ST == 0x90 and D1 == 0x5A and D2 > 0:
        DM.SONG_PATTERN(payload)
        refresh(payload)
        return

# === REFRESH: DAW → LEDs (state-driven) ===
def refresh(payload):
    DM = payload["daw_map"]
    from v1_core import led_cache

    def SEND(note, value):
        if led_cache.only_if_changed((0x90, note), value):
            DM.SEND_DAW(payload, (0x90, note, value))

    SEND(0x7B, 127 if DM.PLAYLIST_GET(payload)  else 0)
    SEND(0x7C, 127 if DM.PIANOROLL_GET(payload) else 0)
    SEND(0x7D, 127 if DM.RACK_GET(payload)       else 0)
    SEND(0x7E, 127 if DM.MIXER_GET(payload)     else 0)
    SEND(0x7F, 127 if DM.BROWSER_GET(payload)   else 0)
    SEND(0x57, 127 if DM.METRONOME_GET(payload) else 0)
    SEND(0x58, 127 if DM.COUNTDOWN_GET(payload) else 0)
    SEND(0x5A, 127 if DM.LOOP_GET(payload)      else 0)

    # forced-off LEDs (also cached)
    SEND(0x52, 0)  # MARKER
    SEND(0x54, 0)  # PREV MARKER
    SEND(0x55, 0)  # NEXT MARKER
    SEND(0x4C, 0)  # UNDO
    SEND(0x4F, 0)  # REDO
    SEND(0x7A, 0)  # ALL WINDOWS

    # === SWITCH BUTTONS ===
    flip_on    = SW.get("flip")
    SEND(0x32, 127 if SW.get("flip") else 0)
