_BLOCK_REFRESH = False

# === ADJUST: HARDWARE → DAW (VPOT CH 0–7)
def adjust(payload):
    global _BLOCK_REFRESH
    _BLOCK_REFRESH = True

    D1 = payload["data1"]
    D2 = payload["data2"]
    HT = payload["tracks"]
    DM = payload["daw_map"]
    AD = payload["addr"]

    vpot = D1 - AD.PAN1_OS
    if vpot < 0 or vpot > 7:
        return

    # VPOT 6–7 → N/A
    if vpot > 5:
        return

    # band mapping
    if vpot <= 2:
        band = vpot              # 0–2 → EQ FREQ
        GET  = DM.EQ_FREQ_GET
        SET  = DM.EQ_FREQ_SET
    else:
        band = vpot - 3          # 3–5 → EQ BW
        GET  = DM.EQ_BANDWIDTH_GET
        SET  = DM.EQ_BANDWIDTH_SET

    # current value
    POS1 = GET(payload, band)
    if not isinstance(POS1, float):
        return

    DIR  = -1.0 if (D2 & AD.PAN_DIR) else 1.0
    STEP = 0.05
    POS2 = POS1 + (DIR * STEP)
    CLAMP = max(0.0, min(1.0, POS2))

    SET(payload, band, CLAMP)

# === REFRESH: DAW → HARDWARE (VPOT CH 0–7)
def refresh(payload):
    DM = payload["daw_map"]
    AD = payload["addr"]

    MODE = AD.MODE_DOT << 4      # standard VPOT ring mode
    PDPV = 10                    # 11 LED positions (0–10)

    for i in range(8):
        CC = AD.VPOT_CC
        D1 = AD.VPOT_OS + i

        # VPOT 6–7 → N/A (blank ring)
        if i > 5:
            DM.SEND_DAW(payload, DM._3_BYTE_MSG(CC, D1, 0x00))
            continue

        if i <= 2:
            band  = i
            value = DM.EQ_FREQ_GET(payload, band)
        else:
            band  = i - 3
            value = DM.EQ_BANDWIDTH_GET(payload, band)

        try:
            CLAMP = max(0.0, min(1.0, float(value)))
        except:
            DM.SEND_DAW(payload, DM._3_BYTE_MSG(CC, D1, 0x00))
            continue

        POS = int(CLAMP * PDPV + 0.5)
        D2  = MODE | (1 + POS)

        DM.SEND_DAW(payload, DM._3_BYTE_MSG(CC, D1, D2))

# === PRESS: HARDWARE (Hardware CH 0–7) — EQ presets
def press(payload):
    DM = payload["daw_map"]
    AD = payload["addr"]

    D1 = payload["data1"]
    i  = D1 - AD.PAN2_OS   # VPOT index 0–7

    # ignore VPOTs 6–7
    if i < 0 or i > 5:
        return

    if i == 0:
        DM.EQ_GAIN_SET(payload, 0, 0.5)
        DM.EQ_FREQ_SET(payload, 0, 0.0881)
    elif i == 1:
        DM.EQ_GAIN_SET(payload, 1, 0.5)
        DM.EQ_FREQ_SET(payload, 1, 0.5057)
    elif i == 2:
        DM.EQ_GAIN_SET(payload, 2, 0.5)
        DM.EQ_FREQ_SET(payload, 2, 0.8618)
    elif i == 3:
        DM.EQ_BANDWIDTH_SET(payload, 0, 0.267)
    elif i == 4:
        DM.EQ_BANDWIDTH_SET(payload, 1, 0.267)
    elif i == 5:
        DM.EQ_BANDWIDTH_SET(payload, 2, 0.267)
