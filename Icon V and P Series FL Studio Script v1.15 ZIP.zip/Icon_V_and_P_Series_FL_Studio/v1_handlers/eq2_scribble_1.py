from v1_handlers.eq2_page import current_page

# === REFRESH: DAW → HARDWARE (Hardware CH 0–7)
def refresh(payload):
    DM = payload["daw_map"]
    AD = payload["addr"]

    page = current_page()  # 0 = FREQ, 1 = BAND

    if page == 0:
        row_labels = [
            "Main   ",
            "Freq 1 ",
            "Freq 2 ",
            "Freq 3 ",
            "Freq 4 ",
            "Freq 5 ",
            "Freq 6 ",
            "Freq 7 ",
        ]
    else:
        row_labels = [
            "Main   ",
            "Band 1 ",
            "Band 2 ",
            "Band 3 ",
            "Band 4 ",
            "Band 5 ",
            "Band 6 ",
            "Band 7 ",
        ]

    CELLS = [s.ljust(7)[:7] for s in row_labels]

    text  = "".join(CELLS)[:56].ljust(56)
    sysex = bytearray(AD.SCRIBBLE_1)
    sysex.extend(text.encode("ascii", "replace"))
    sysex.append(0xF7)

    DM.SEND_DAW(payload, tuple(sysex))
